#!/usr/bin/env bash

echo 'Setup Splunk Env'
source ./setSplunkEnv

echo 'Start pstack on splunkd'
python collect-data-all.py  --regex=PSTACKME -- bash -c 'touch "{SEARCHDIR}/save"; ./collect-stacks.sh --batch --outdir="{SEARCHDIR}" --pid="{PID}" --samples=120'
echo 'done'
