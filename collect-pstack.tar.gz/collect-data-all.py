#!/usr/bin/env python
import sys
import os
import glob
import argparse
import re
import csv
import subprocess
import time

# TODO: do we always want to `touch save`? maybe this should be done by default
# TODO: abort command when search finished, regardless of the process being still alive due to reuse? maybe that should be optional with default being that we do kill it


SPLUNK_HOME = os.environ.get('SPLUNK_HOME', '/opt/splunk')

examples = '''
examples:
    Collect stack dumps using the collect-stacks.sh script as soon as a search containing the PSTACKME keyword starts (eg by appending `| fields *, PSTACKME` to the search):
        {SCRIPT} --regex=PSTACKME -- ~/collect-stacks.sh --batch --outdir='{SEARCHDIR}' --pid='{PID}'

    Do the same stack dump collection, but touch save in the dispatch directory first (we don't want it to be reaped!):
        {SCRIPT} --regex=PSTACKME -- bash -c 'touch "{SEARCHDIR}/save"; ~/collect-stacks.sh --batch --outdir="{SEARCHDIR}" --pid="{PID}"'

    Collect system trace from a similar STRACEME search:
        {SCRIPT} --regex=STRACEME -- bash -c 'touch "{SEARCHDIR}/save"; strace -ttt -T -f -x -y -s999 -o "{SEARCHDIR}/strace.out" -p "{PID}"'
'''

parser = argparse.ArgumentParser(
    formatter_class=argparse.RawDescriptionHelpFormatter,
    description='Monitor splunk searches, run command as soon as a search being executed matches given regular expression.',
    epilog=examples.replace('{SCRIPT}', sys.argv[0]))
parser.add_argument('-r', '--regex',       dest='regex',      default="PSTACKME",  help='Regular expression to match in search (mandatory).')
parser.add_argument('-s', '--splunkhome',  dest='splunkhome', default=SPLUNK_HOME, metavar='SPLUNK_HOME', help='Splunk home (default is "'+SPLUNK_HOME+'").')
parser.add_argument('-b', '--backup-logs', dest='backupLogs', type=int, default=0, metavar='N', help='Backup up to N search.log files to forcefully preserve them, 0 means all (default 0).')
parser.add_argument('-v', '--verbose',     dest='verbose',    action='store_true', help='Verbose output (default false).')
parser.add_argument('-p', '--period',      dest='period',     type=float, default=.2, metavar='SECONDS', help='Time, in seconds, between sweeps of dispatch directory looking for new searches (default 0.2).')
parser.add_argument('command', metavar='COMMAND_ARG', type=str, nargs='+', help='Command to execute when process is found ({PID} will be replaced with the matched search PID, and similarly for {SID} and {SEARCHDIR})')
args = parser.parse_args()

if args.regex is None:
    sys.stderr.write("error: argument -r/--regex is mandatory")
    sys.exit(1)

try:
    regex = re.compile(args.regex)
except re.error as e:
    sys.stderr.write("error: argument -r/--regex: invalid regular expression '", args.regex, "' given -- ", str(e))
    sys.exit(1)

dispatch = os.path.join(args.splunkhome, 'var', 'run', 'splunk', 'dispatch')
if not os.path.isdir(dispatch):
    sys.stderr.write("error: argument -s/--splunkhome: can't find '", dispatch, '" -- did you remember to set --splunkhome?')
    sys.exit(1)

pidFile = os.path.join(args.splunkhome, 'var', 'run', 'splunk', 'splunkd.pid')
if not os.path.isfile(pidFile):
    sys.stderr.write("error: argument -s/--splunkhome: can't find '", dispatch, '" -- is splunk running?')
    sys.exit(1)

if args.backupLogs<0:
    sys.stderr.write("error: argument -b/--backup-logs cannot be negative")
    sys.exit(1)

if args.command is None:
    sys.stderr.write("error: `COMMAND_ARG` is a mandatory argument")
    sys.exit(1)

def getSplunkPids():
    pids = []
    with open(pidFile, 'r') as f:
        for line in f:
            pids.append(line.strip())
    return pids

def getLinuxProcessArgs(pid):
    args = []
    try:
        with open(os.path.join('/proc', pid, 'cmdline'), 'r') as proc_cmdline:
            args = ' '.join([line.strip() for line in proc_cmdline.read().split('\0') if line.strip()])
    except:
        print("Error reading command line for PID ", pid, " -- ignoring")
    return args

def run_command(cmd, outdir, outpath):
    command = "./collect-command.sh {0} --outdir={1} --outfile={2} ".format(cmd, outdir, outpath).split(' ')
    try:
        process = subprocess.Popen(command, shell=False)
    except Exception as e:
        sys.stderr.write("\nError running command {0}\n".format(e))
        sys.exit(1)
    return process


logpath = os.path.join(args.splunkhome, 'var', 'log', 'splunk')

processes = []
splunkd_pid = getSplunkPids()[0]

# collect rotate pstack for splunkd
splunkd_pid = getSplunkPids()[0]
command = "./collect-stacks.sh --batch --outdir={0} --pid={1} --interval=1.0 --samples=8640 -c -q".format(logpath, splunkd_pid)
# print(command)
command = command.split(' ')
# print(command)
try:
    processes.append(subprocess.Popen(command, shell=False))
except Exception as e:
    sys.stderr.write("\nError running command {0}\n".format(e))

# collect pstack for the search process
discardedDispatch = {}
while True:
    for dispatchDir in glob.glob(os.path.join(dispatch, '*')):
        sid = os.path.basename(dispatchDir)
        if sid in discardedDispatch:
            continue
        if args.verbose:
            print("Exploring " + dispatchDir)
        infoFile = os.path.join(dispatchDir, 'info.csv')
        try:
            with open(infoFile, 'r') as f:
                dictReader = csv.DictReader(f)
                searchInfo = next(dictReader)
        except Exception as e:
            if args.verbose:
                print("Skipping ", infoFile, " because hit error ", str(e))
            continue
        
        if re.search(regex, searchInfo["_search"]):
            print("Found", regex)
            pid = None
            for potentialPid in getSplunkPids():
                if args.verbose:
                    print("Checking potential pid=", potentialPid, " to see if it's running search ", sid)
                if ("--id="+sid) in getLinuxProcessArgs(potentialPid):
                    pid = potentialPid
                    if args.verbose:
                        print("Matched search on pid=" + pid)
                    break
            if pid is not None:
                for i, arg in enumerate(args.command):
                    args.command[i] = arg.replace('{PID}', pid).replace('{SID}', sid).replace('{SEARCHDIR}', dispatchDir)

                print("Matched in directory='", dispatchDir, "', PID=", pid, ". Now running command=`'", "' '".join(args.command), "'`\n")
                try:
                    process = subprocess.Popen(args.command, shell=False)
                except Exception as e:
                    sys.stderr.write("\nError running command `", "' '".join(args.command), "`: ", str(e), "\n")
                    sys.exit(1)

                if args.backupLogs >= 0:
                    iNode = -1
                    logPath = os.path.join(dispatchDir, 'search.log')
                    storedFiles = []
                    while process.poll() is None:
                        try:
                            stat = os.stat(logPath)
                            if stat.st_ino!=iNode:
                                name = logPath + ".from." + str(stat.st_ctime)
                                os.link(logPath, name)
                                storedFiles.append(name)
                                if args.backupLogs!=0 and len(storedFiles) > args.backupLogs:
                                    os.remove(storedFiles.pop(0))
                                iNode = stat.st_ino
                        except:
                            pass
                        time.sleep(0.2)

                process.communicate()
                if process.returncode!=0:
                    sys.stderr.write("\nError, got return code {0} running command {1}\n".format(process.returncode, " ".join(args.command)))

        discardedDispatch[sid] = 1
    time.sleep(args.period)

for proc in processes:
    proc.kill()
