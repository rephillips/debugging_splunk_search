#!/usr/bin/env bash

SPLUNK_HOME=${SPLUNK_HOME:-/opt/splunk}

set -e
set -u
#set -x

platform="$(uname)"
if [[ "$platform" != 'Linux' ]]; then
    echo "ERROR: This script is only tested on Linux, \`uname\` says this is '$platform'" >&2
    exit 1
fi

function usage()
{
     echo "Usage: $0 [OPTION]"
     echo "Collect \"top -b\" for splunk support."
     echo
     echo "  -o, --outdir=PATH         Output directory. Default is '/tmp/splunk'"
}

function printout() {
    if [ $quiet -eq 0 ]; then
        echo $@
    fi
}

function run() {
    if [ -z "$nsenter_prefix" ]; then
        eval "$@"
    else
        $nsenter_prefix bash -c "$*"
    fi
}

abort=0
quiet=0
subprocesses=''
container=''
function wait_subprocesses_revive_pid() {
    # `wait` won't work because we use setsid for stack collection, so we
    # improvise in a very ugly way
    for proc in $subprocesses; do
        run "while [ -e /proc/$proc ]; do sleep 0.1; done"
    done
}

outfile='out'
outdir='/tmp/splunk'
com=''
while [ "$#" -ne "0" ] ; do
    case "$1" in
        -h|-\?|--help)   usage; exit;;
        --outdir=*) outdir=${1#*=};;
        --outdir)
            shift
            if [ "$#" -ne "0" ]; then outdir="$1"; else outdir=''; fi
            ;;
        --outfile=*) outfile=${1#*=};;
        --outfile)
            shift
            if [ "$#" -ne "0" ]; then outfile="$1"; else outfile=''; fi
            ;;
        *)
            com="${com} $1"
            ;;
    esac

    if [ "$#" -ne "0" ]; then shift; fi
done

nsenter_prefix=""
if ! [ -z "$container" ]; then
    set +e
    err="$(docker inspect --format {{.State.Pid}} "$container" 2>&1)"
    if [ "$?" -ne "0" ]; then
        echo "ERROR: invalid value for --docker option, are you sure your container ID is running? '$container': $err" >&2
        exit 1
    fi
    nsenter_prefix="nsenter --target $err --mount --pid"
fi

set +e
err="$(mkdir -p "$outdir" 2>&1)"
if [ "$?" -ne "0" ]; then
    echo "ERROR: invalid value for --outdir option, '$outdir': $err" >&2
    exit 1
fi
set -e

run "$($com > $outdir/$outfile 2>&1)" &
subprocesses=$!
wait_subprocesses_revive_pid

printout